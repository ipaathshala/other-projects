<!doctype html>
<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>BunGee - Blog, News & Magazine HTML5 Template</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="manifest" href="site.html">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
    <!-- Place favicon.ico in the root directory -->
    <!-- CSS here -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <link rel="stylesheet" href="assets/css/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/meanmenu.css">
    <link rel="stylesheet" href="assets/css/slick.css">
    <link rel="stylesheet" href="assets/css/style.css">
  </head>
  <body>
    <!--[if lte IE 9]>
    <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
    <![endif]-->
    <!-- Add your site or application content here -->
    <!-- header start -->
    <?php require_once('include/header.php');?>
    <!-- header end -->
    <main>
      <!-- page-title-area start -->
      <div class="page-title-area">
        <div class="container">
          <div class="row">
            <div class="col-12">
              <div class="page-title text-center pt-30">
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item">
                      <a href="index.html">Home</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page"> About us</li>
                  </ol>
                </nav>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- page-title-area end -->
      <section class="post-details-area pt-60 pb-30">
        <div class="container">
          <div class="row">
            <div class="col-xl-12 col-lg-12">
              <div class="row">
                <div class="col-xl-4 col-lg-4">
                  <div class="post-thumb mb-25">
                    <img src="assets/img/details/post.jpg" alt="">
                  </div>
                </div>
                <div class="col-xl-8 col-lg-8">
                  <div class="post-details">
                    <h2 class="details-title mb-15">Group continues to sell and market memberships to Premier country club despite.</h2>
                    <div class="post-content">
						<p class="text-justify"><b>COURSE :</b> </p>
						<p class="text-justify"><b>SUB COURSE :</b> </p>
						<p class="text-justify"><b>SUBJECT :</b> </p>
						
                      <p class="text-justify">Excepteur sint occaecat cupidatat non proident sunt in culpa qui officia deserunt mollit anim id est Cura tbitur pretium
                        tincidunt lacus. Nulla gravida orci a odio. Nullam varius turpis et commodo pharetra es ero biben dum elit nec luctus magna
                        felis sollicitudin mauris. Integer in mauris eu nibh euismod gravida. Duis ac tellus erisus vulputate vehicula. Donec lobortis
                        risus a elit. Etiam tempor. Ut ullamcorper ligula eu tempor congue eros est euismod turpis id tincidunt sapien risus.
                      </p>
                      <div align="right"><button class="btn pull-right"><i class="fa fa-shopping-cart"></i> BUY NOW</button></div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-xl-12 col-lg-12">
                  <div class="post-details">
                    <div class="also-like mt-30">
                      <div class="section-title mb-30">
                        <h2>Package includes</h2>
                      </div>
                      <div class="row">
                        <div class="col-lg-2 col-md-2">
                          <div class="postbox mb-30">
                            <div class="postbox__thumb">
                              <img class="img-100" src="assets/img/trendy/sm1.jpg" alt="hero image">
                            </div>
                            <div class="postbox__text pt-10">
                              <h4 class="pr-0">Paul Manafort’s Accountant Testifies She Helped Alter Financial</h4>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
    <!-- footer -->
    <?php require_once('include/footer.php');?>
    <!-- footer end -->
    <!-- JS here -->
    <script src="assets/js/vendor/modernizr-3.5.0.min.js"></script>
    <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <script src="assets/js/one-page-nav-min.js"></script>
    <script src="assets/js/slick.min.js"></script>
    <script src="assets/js/jquery.meanmenu.min.js"></script>
    <script src="assets/js/ajax-form.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/jquery.scrollUp.min.js"></script>
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/main.js"></script>
	<script src="assets/custom-js/loader.js"></script>
	<script src="assets/custom-js/pkgDetail.js"></script>
  </body>
</html>
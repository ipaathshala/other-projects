<?php
	require_once('../../admin/include/config.php');
	
	session_destroy();
	echo true;
?>
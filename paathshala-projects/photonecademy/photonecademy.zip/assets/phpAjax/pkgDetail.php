<?php
	require_once('../../admin/include/config.php');
	
	$reqId = mysqli_real_escape_string($con, $_REQUEST['pkgId']);
	$sql = mysqli_query($con,"SELECT
	sub_package.subpkg_id,
	master_package.pkg_name,
	master_course.course_name,
	sub_course.subcourse_name,
	master_subject.subject,
	master_topics.topic_title
	FROM
	sub_package
	LEFT JOIN master_package ON master_package.pkg_id = sub_package.masterpkgid
	LEFT JOIN master_course ON master_course.course_id = sub_package.courseid
	LEFT JOIN sub_course ON sub_course.subcourse_id = sub_package.subcourseid
	LEFT JOIN master_subject ON master_subject.sub_id = sub_package.subjectid
	LEFT JOIN master_topics ON master_topics.topic_id = sub_package.topicid
	WHERE
	sub_package.masterpkgid = '$reqId'");
?>
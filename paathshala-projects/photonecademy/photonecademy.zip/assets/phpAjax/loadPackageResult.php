<?php
	require_once('../../admin/include/config.php');

	$pkgId = mysqli_real_escape_string($con, $_REQUEST['pkgid']);
	/*$courseId = mysqli_real_escape_string($con, $_REQUEST['courseid']);
	$subcourseId = mysqli_real_escape_string($con, $_REQUEST['subcourseid']);
	$subjectId = mysqli_real_escape_string($con, $_REQUEST['subjectid']);*/
	
	$sql = mysqli_query($con,"SELECT `pkg_id`, `pkg_name`, `pkg_img`, `pkg_status` FROM `master_package` WHERE `pkg_id` = '$pkgId'");
	$array = array();
	$row = mysqli_fetch_array($sql);
	foreach($sql as $row){
		$postArray[] = array('pid'=>$row["pkg_id"], 'pkgname'=>strtoupper($row["pkg_name"]), 'img'=>$row["pkg_img"]);
	}
	echo json_encode($postArray);
	
	/*
	$sql = mysqli_query($con,"SELECT sub_package.masterpkgid, master_package.pkg_name, master_package.pkg_img FROM sub_package LEFT JOIN master_package ON master_package.pkg_id = sub_package.masterpkgid WHERE sub_package.masterpkgid = '$pkgId'");
	
	echo $sql = ("SELECT
	master_package.pkg_id,
	master_package.pkg_name,
	master_package.pkg_img,
	sub_package.subpkg_id
	FROM sub_package
	LEFT JOIN master_package ON master_package.pkg_id = sub_package.masterpkgid
	LEFT JOIN master_course ON master_course.course_id = sub_package.courseid
	LEFT JOIN sub_course ON sub_course.subcourse_id = sub_package.subcourseid
	LEFT JOIN master_subject ON master_subject.sub_id = sub_package.subjectid
	WHERE
	master_package.pkg_id = '$pkgId' AND
	master_course.course_id='$courseId' AND
	sub_course.subcourse_id = '$subcourseId' AND
	master_subject.sub_id = '$subjectId'");*/
	
?>
<div class="topbar">
  <div class="topbar-left"><a href="dashboard" class="logo"><span><img src="plugins/assets/images/logo-light.png" alt="" height="18"> </span><i><img src="plugins/assets/images/logo-sm.png" alt="" height="22"></i></a></div>
  <nav class="navbar-custom">
    <ul class="list-inline menu-left mb-0">
      <li class="float-left"><button class="button-menu-mobile open-left waves-effect"><i class="mdi mdi-menu"></i></button></li>
    </ul>
  </nav>
</div>
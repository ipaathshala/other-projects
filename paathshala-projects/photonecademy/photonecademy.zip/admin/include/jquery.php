<script src="plugins/assets/js/jquery.min.js"></script>
<script src="plugins/assets/js/bootstrap.bundle.min.js"></script>
<script src="plugins/assets/js/metisMenu.min.js"></script>
<script src="plugins/assets/js/jquery.slimscroll.js"></script>
<script src="plugins/assets/js/waves.min.js"></script>
<script src="plugins/jquery-sparkline/jquery.sparkline.min.js"></script>
<script src="plugins/parsleyjs/parsley.min.js"></script>
<script src="plugins/assets/js/app.js"></script>
<link rel="shortcut icon" href="plugins/assets/images/favicon.ico">
<link href="plugins/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="plugins/assets/css/metismenu.min.css" rel="stylesheet" type="text/css">
<link href="plugins/assets/css/icons.css" rel="stylesheet" type="text/css">
<link href="plugins/assets/css/style.css" rel="stylesheet" type="text/css">
$(document).ready(function(){
	$("#invname, #invemail, #invmob, #invcourse, #fail, #success, #loader").hide();
	$("form").submit(function(){
		var name	=	$("#name").val();
		var email	=	$("#email").val();
		var mobile	=	$("#mobile").val();
		var course	=	$("#course").val();
		var regex	=	/^[a-zA-Z ]*$/;
		var pattern	=	/^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b$/i;
		var num		=	/^[0-9\s]*$/;
		
		if(name==='' || !regex.test(name)){
			$("#invname").delay(2000).show().fadeOut('slow');
			return false;
		}
		else if(email==='' || !pattern.test(email)){
			$("#invemail").delay(2000).show().fadeOut('slow');
			return false;
		}
		else if(mobile==='' || !num.test(mobile) || mobile.length!==10){
			$("#invmob").delay(2000).show().fadeOut('slow');
			return false;
		}
		else if(course=='0'){
			$("#invcourse").delay(2000).show().fadeOut('slow');
			return false;
		}
		else{
			$.ajax({
				type:'POST',
				url:'assets/php/quick-enquiry.php',
				data: new FormData (this),
				contentType: false,
				cache: false,
				processData:false,
				beforeSend:function(result){
					$("button").hide();
					$("#loader").show();
				},
				success:function(result){
					if(result == true){
						$("#loader").hide();
						$("#success").delay(2000).show().fadeOut('slow');
						$("form").trigger("reset");
						$("button").show();
					}
				},
				error:function(error) {
					$("#loader").hide();
					$("button").show();
					$("#fail").delay(2000).show().fadeOut('slow');
					return false;
				},
				complete:function(result) {
					$("#loader").hide();
				}
			});
			return false;
		}
	});
});
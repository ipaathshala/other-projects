<?php
	$name	=	htmlentities($_POST['name']);
	$email	=	htmlentities($_POST['email']);
	$mobile	=	htmlentities($_POST['mobile']);
	$course	=	htmlentities($_POST['course']);
	
	$c1	=	"foundations-programs-prayaag";
	$c2	=	"iit-jee-mains-advanced-boards";
	$c3	=	"mains-advanced-boards";
	$c4	=	"medical-entrance-boards";
	$c5	=	"jam-gate";
	$c6	=	"kvpy-and-olympiads";
	
	if($course=='1'){
		$course==$c1;
	}
	else if($course=='2'){
		$course==$c2;
	}
	else if($course=='3'){
		$course==$c3;
	}
	else if($course=='4'){
		$course==$c4;
	}
	else if($course=='5'){
		$course==$c5;
	}
	else if($course=='6'){
		$course==$c6;
	}
	else{
		echo true;
	}
?>
<?php error_reporting(0);?>
<section class="padding-tb-100px background-dark wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
  <!-- Section Title -->
  <div class="container padding-bottom-40px wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
    <div class="row justify-content-center text-center">
      <div class="col-md-7">
        <h1 class="text-white text-center"><span class="padding-tb-10px padding-lr-40px border-3">Get In Touch</span></h1>
      </div>
    </div>
  </div>
  <!-- end Section Title -->
  <div class="container">
    <div class="row">
      <div class="col-lg-2"></div>
      <div class="col-lg-8">
        <form class="dark-form" method="post">
          <div class="form-row">
			<div class="form-group col-md-12">
              <b class="text-danger" id="fail">* Oops something goes wrong</b>
              <b class="text-success" id="success">Thank you! We will get back to you soon</b>
            </div>
            <div class="form-group col-md-6">
              <label>Name</label>
			  <b class="text-danger" id="invname">* Invalid name format</b>
              <input type="text" class="form-control" id="name" name="name" value="<?php echo $_POST['name'];?>" autocomplete="off">
            </div>
            <div class="form-group col-md-6">
              <label>Email</label>
			  <b class="text-danger" id="invemail">* Invalid email format</b>
              <input type="text" class="form-control" id="email" name="email" value="<?php echo $_POST['email'];?>" autocomplete="off">
            </div>
            <div class="form-group col-md-6">
              <label>Mobile</label>
			  <b class="text-danger" id="invmob">* Invalid mobile number</b>
              <input type="text" class="form-control" id="mobile" name="mobile" value="<?php echo $_POST['mobile'];?>" autocomplete="off">
            </div>
            <div class="form-group col-md-6">
              <label>Select</label>
			  <b class="text-danger" id="invcourse">* Select option</b>
              <select class="form-control" name="course" id="course">
                <option value="0">Select</option>
                <option value="1">Foundations Programs-Prayaag</option>
                <option value="2">IIT JEE Mains,Advanced+Boards</option>
                <option value="3">Mains,Advanced+Boards</option>
                <option value="4">Medical Entrance+Boards</option>
                <option value="5">JAM/GATE</option>
                <option value="6">KVPY and Olympiads</option>
              </select>
            </div>
          </div>
          <div class="form-group">
            <button type="submit" name="submit" class="btn-sm btn-lg btn-primary btn-block border-2 border-white text-white text-center font-weight-bold text-uppercase rounded-0 padding-15px">SUBMIT</button>
          </div>
		  <div class="form-group" align="center" id="loader">
			<i class="fa fa-spinner fa-spin fa-3x text-success"></i>
          </div>
        </form>
      </div>
      <div class="col-lg-2"></div>
    </div>
  </div>
</section>
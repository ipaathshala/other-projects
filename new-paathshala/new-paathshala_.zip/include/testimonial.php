<section class="padding-tb-100px background-grey">
      <div class="container">
        <div class="text-center margin-bottom-35px wow fadeInUp">
          <h1 class="font-weight-300 text-title-large font-3">Testimonial</h1>
          <span class="opacity-7">Lorem Ipsum Dolor Sit Amet, Consectetur Adipisicing Elitdunt</span>
        </div>
        <div class="testimonial-carousel owl-carousel owl-theme wow fadeInUp">
          <div class="item margin-lr-15px">
            <div class="background-white opacity-hover-7 padding-30px">
              <div class="float-left width-50px margin-right-20px">
                <img src="assets/img/zoal_1.jpg" alt="">
              </div>
              <h4 class="margin-bottom-0px">Rabie Elkheir</h4>
              <small>Web Designer</small>
              <hr>
              <p class="text-grey-2">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>
            </div>
          </div>
          <div class="item margin-lr-15px">
            <div class="background-white opacity-hover-7 padding-30px">
              <div class="float-left width-50px margin-right-20px">
                <img src="assets/img/zoal_2.jpg" alt="">
              </div>
              <h4 class="margin-bottom-0px">Firdous Fadlalla</h4>
              <small>Web Designer</small>
              <hr>
              <p class="text-grey-2">The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here'</p>
            </div>
          </div>
          <div class="item margin-lr-15px">
            <div class="background-white opacity-hover-7 padding-30px">
              <div class="float-left width-50px margin-right-20px">
                <img src="assets/img/zoal_3.jpg" alt="">
              </div>
              <h4 class="margin-bottom-0px">Moh Elkheir</h4>
              <small>Web Designer</small>
              <hr>
              <p class="text-grey-2">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>
            </div>
          </div>
          <div class="item margin-lr-15px">
            <div class="background-white opacity-hover-7 padding-30px">
              <div class="float-left width-50px margin-right-20px">
                <img src="assets/img/zoal_4.jpg" alt="">
              </div>
              <h4 class="margin-bottom-0px">Moh Elkheir</h4>
              <small>Web Designer</small>
              <hr>
              <p class="text-grey-2">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>
            </div>
          </div>
          <div class="item margin-lr-15px">
            <div class="background-white opacity-hover-7 padding-30px">
              <div class="float-left width-50px margin-right-20px">
                <img src="assets/img/zoal_5.jpg" alt="">
              </div>
              <h4 class="margin-bottom-0px">Moh Elkheir</h4>
              <small>Web Designer</small>
              <hr>
              <p class="text-grey-2">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>
            </div>
          </div>
          <div class="item margin-lr-15px">
            <div class="background-white opacity-hover-7 padding-30px">
              <div class="float-left width-50px margin-right-20px">
                <img src="assets/img/zoal_6.jpg" alt="">
              </div>
              <h4 class="margin-bottom-0px">Moh Elkheir</h4>
              <small>Web Designer</small>
              <hr>
              <p class="text-grey-2">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>
            </div>
          </div>
        </div>
      </div>
    </section>
<section class="padding-tb-100px">
  <div class="container">
    <div class="text-center margin-bottom-35px wow fadeInUp">
      <h1 class="font-weight-300 text-title-large font-3">Our Clients</h1>
      <span class="opacity-7">Lorem Ipsum Dolor Sit Amet, Consectetur Adipisicing Elitdunt</span>
    </div>
    <ul class="row clients-border no-gutters padding-0px margin-0px list-unstyled text-center">
      <li class="col-md-3 col-6 padding-tb-30px hvr-bounce-out wow fadeInUp">
        <a class="hvr-bounce-out" href="#"><img src="assets/img/client/1.png" alt=""></a>
      </li>
      <li class="col-md-3 col-6 padding-tb-30px wow fadeInUp" data-wow-delay="0.2s">
        <a class="hvr-bounce-out" href="#"><img src="assets/img/client/2.png" alt=""></a>
      </li>
      <li class="col-md-3 col-6 padding-tb-30px wow fadeInUp" data-wow-delay="0.4s">
        <a class="hvr-bounce-out" href="#"><img src="assets/img/client/3.png" alt=""></a>
      </li>
      <li class="col-md-3 col-6 padding-tb-30px wow fadeInUp" data-wow-delay="0.6s">
        <a class="hvr-bounce-out" href="#"><img src="assets/img/client/4.png" alt=""></a>
      </li>
    </ul>
  </div>
</section>
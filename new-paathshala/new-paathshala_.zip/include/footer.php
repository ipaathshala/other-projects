<footer class="padding-top-60px background-black">
  <div class="container">
    <div class="row">
      <div class="col-lg-4 col-md-6 sm-mb-30px wow fadeInUp">
        <div class="logo margin-bottom-10px"><img src="assets/img/logo-light.png" alt=""></div>
        <div class="text-grey-2  font-weight-300">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy .</div>
        <ul class="list-inline text-left margin-tb-20px margin-lr-0px text-white">
          <li class="list-inline-item"><a class="facebook" href="#"><i class="fab fa-facebook-f"></i></a></li>
          <li class="list-inline-item"><a class="youtube" href="#"><i class="fab fa-youtube"></i></a></li>
          <li class="list-inline-item"><a class="linkedin" href="#"><i class="fab fa-linkedin"></i></a></li>
          <li class="list-inline-item"><a class="google" href="#"><i class="fab fa-google-plus"></i></a></li>
          <li class="list-inline-item"><a class="twitter" href="#"><i class="fab fa-twitter"></i></a></li>
          <li class="list-inline-item"><a class="rss" href="#"><i class="fa fa-rss" aria-hidden="true"></i></a></li>
        </ul>
      </div>
      <div class="col-lg-4  col-md-6 sm-mb-30px wow fadeInUp" data-wow-delay="0.4s">
        <ul class="footer-menu-2 row margin-0px padding-0px list-unstyled">
          <li class="col-6  padding-tb-5px"><a href="index" class="text-grey-2">Home</a></li>
          <li class="col-6  padding-tb-5px"><a href="about-us" class="text-grey-2">About Us</a></li>
          <li class="col-6  padding-tb-5px"><a href="why-paathshala" class="text-grey-2">Why Paathshala</a></li>
          <li class="col-6  padding-tb-5px"><a href="why-paathshala" class="text-grey-2">Engineering Entrance </a></li>
          <li class="col-6  padding-tb-5px"><a href="#" class="text-grey-2">IIT JEE</a></li>
          <li class="col-6  padding-tb-5px"><a href="#" class="text-grey-2">NEET Exam</a></li>
          <li class="col-6  padding-tb-5px"><a href="#" class="text-grey-2">Medical Entrance</a></li>
		  
          <li class="col-6  padding-tb-5px"><a href="contact-us" class="text-grey-2">Contact Us</a></li>
        </ul>
      </div>
      <div class="col-lg-4 col-md-6 sm-mb-30px wow fadeInUp">
        <p class="text-grey-2"> Office : 201, Dighe House, Opp Karnavat Classes, <br>Lohar Ali Lane, Behind Jagdish Book Depot, <br>Near Thane Railway Station, Thane West - 400601, Maharashtra, India</p>
        <p class="text-grey-2"> Enquiries : 9867998388</p>
        <p class="text-grey-2">	Admin Office : 022 49708979</p>
        <p class="text-grey-2"> Student Welfare : 9987457772</p>
        <p class="text-grey-2">Email us : enquiries@paathshala.world</p>
      </div>
    </div>
    <hr class="border-grey-4">
    <div class="row padding-bottom-30px padding-top-10px wow fadeInUp">
      <div class="col-lg-6"><span class="text-grey-2 d-block padding-top-5px">Copyright &copy; 2018 | All rights reserved.</span></div>
      <div class="col-lg-6">
        <span class="text-lg-right text-grey-2 d-block padding-top-5px">Design &amp; Developed By - <a href="#" class="text-grey-2">Paathshala Education</a></span>
      </div>
    </div>
  </div>
</footer>
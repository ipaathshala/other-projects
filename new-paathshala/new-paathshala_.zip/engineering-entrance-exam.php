<!DOCTYPE html>
<html lang="en-US">
  <head>
    <title>Engineering Entrance Exam</title>
    <meta name="author" content="Nile-Theme">
    <meta name="robots" content="index follow">
    <meta name="googlebot" content="index follow">
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php require_once('include/header-css.php');?>
  </head>
  <body class="background-white">
    <!-- header -->
    <?php require_once('include/header.php');?>
    <!-- Page title --->
    <section class="background-grey-1 padding-tb-25px text-grey-4">
      <div class="container">
        <ol class="breadcrumb z-index-2 position-relative no-background padding-tb-10px padding-lr-0px  margin-0px float-md-right">
          <li><a href="index" class="text-grey-4">Home</a></li>
          <li><strong>You are here</strong></li>
          <li class="active"><strong>Engineering Entrance Exams</strong></li>
        </ol>
        <div class="clearfix"></div>
      </div>
    </section>
    <div class="padding-tb-50px">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <ul class="nav nav-tabs nav-tabs-2" role="tablist">
              <li class="nav-item">
                <a class="nav-link active" data-toggle="tab" href="#home-1" role="tab" aria-selected="false">Exam Overview</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#profile-1" role="tab" aria-selected="false">Exam Syllabus</a>
              </li>
            </ul>
            <div class="tab-content">
              <div class="tab-pane background-light-grey padding-30px active" id="home-1" role="tabpanel">
                <div id="accordion" role="tablist" aria-multiselectable="true" class="margin-bottom-100px">
                  <div class="card">
                    <div class="card-header" role="tab" id="headingOne">
                      <h5 class="mb-0">
                        <a data-toggle="collapse" data-parent="#accordion" href="#collapse-1" aria-expanded="true" aria-controls="collapseOne" class="d-block text-dark text-capitalize text-up-small font-weight-700"> JEE</a>
                      </h5>
                    </div>
                    <div id="collapse-1" class="collapse show" role="tabpanel" aria-labelledby="headingOne">
                      <div class="card-block padding-30px text-justify">
                        <p>Candidates can write JEE Main in English or Hindi. Students from Gujarat may choose to write exams in Gujarati medium.</p>
                        <p>EXAM PATTERN OF JEE MAIN PAPER 1</p>
                        <p>Question paper will have three sections: Physics, Chemistry and Mathematics</p>
                        <p>30 questions will be asked in each section. Overall, 90 questions will be asked in the Paper 1 exam. The exam will have objective-type multiple-choice questions. For each question, four choices will be given. Only one will be correct. Each question will be of 4 marks. One mark will be deducted from the total score for each incorrect answer. No marks will be deducted for un-attempted questions.</p>
                        <p>COMPUTER BASED TEST (CBT) (ONLINE JEE MAIN EXAM)</p>
                        <p>Question paper will have three sections: Physics, Chemistry and Mathematics 30 questions will be asked in each section. Overall, 90 questions will be asked in the Paper 1 exam. The exam will have objective-type multiple-choice questions. For each question, four choices will be given. Only one will be correct. Each question will be of 4 marks. One mark will be deducted from the total score for each incorrect answer. No marks will be deducted for un-attempted questions.</p>
                        <p>JEE MAIN ONLINE VS OFFLINE MODE | PROS &amp; CONS</p>
                        <p>JEE online Vs offline’, people have this confusion of what to choose and on a very simple note, there is no big difference in both of the types and any of them is totally fine.</p>
                        <p><b>Some minor differences which are there is as following :</b></p>
                        <p><b>Pros of JEE Mains Online Mode:</b></p>
                        <p>Candidates can choose their preferred timing and date of the exam according to the slots available as per convenience.</p>
                        <p>The restrictions of OMR Sheet: You can always change a marked answer in online mode. This freedom is lost in offline mode because, well, the ink is everlasting.</p>
                        <p>Assigning extra time for bubbling: Personally as a student, I would always have to keep extra ten minutes aside to colour the bubbles of OMR sheet. Of course, you cannot rush this process. On the contrary, online mode offers marking answers with one click!</p>
                        <p>Information like number of questions answered, number of questions unanswered, answers marked for review is available on the screen and in different colours.</p>
                        <p>The application fee in online mode is lower than paper and pen mode.</p>
                        <p>Students surely prefer an air conditioned room provided in online mode on a sweating summer afternoon. Perspiring improves concentration, said no soul ever!</p>
                        <p><b>Cons of JEE Mains Online Mode:</b></p>
                        <p>Technical glitches: These can occur anywhere and at most abrupt of times, especially in smaller towns with lesser technical expertise. If you feel that the facilities are not sufficient, you might want to sit this one out.</p>
                        <p>Question Paper is not given to students for further reference. Looking at the computer screen for 3 hours could be strenuous for eyes. Power cuts: A usual event in our country, not all facilities are provided with equipments to tackle power cuts. Why take a chance? Pros of JEE Mains Offline Mode: Reviewing the question paper: Students can go through the paper as per convenience. This helps them choose the section of their strength and begin with it. No technical glitches or power failure fear: Since the examination is on paper, you couldn’t care less about the lack of equipped facilities or faculty. Conventional: This mode is highly conventional owing to our education system, and hence students find it highly comfortable. Students get to take the question paper for future reference.</p>
                        <p><b>Cons of JEE Mains Offline Mode :</b></p>
                        <p>Bubbling: The strenuous task of bubbling OMR, as mentioned earlier, eats up students’ crucial time which could have been used for revision. Also, it does not leave scope for correction of wrongly marked answer. The application fee is more than online mode. Students have to appear in the exam on allotted date and time. Weigh each side on your own, for every student mind is moulded differently and each of you may have different preference. As long as you have the choice, choose the mode which suits you best and brings out the best in you.</p>
                        <p>JEE MAIN PAPER 2 EXAM PATTERN</p>
                        <p>Paper 2 will have objective multiple-choice questions in the first two sections and questions related to drawing aptitude in the third section. Its three parts will be as follows: Part I for Mathematics, Part II for Aptitude Test, and Part III for Drawing Test.</p>
                      </div>
                    </div>
                  </div>
                  <div class="card">
                    <div class="card-header" role="tab" id="headingOne">
                      <h5 class="mb-0">
                        <a data-toggle="collapse" data-parent="#accordion" href="#collapse-2" aria-expanded="true" aria-controls="collapseOne" class="d-block text-dark text-capitalize text-up-small font-weight-700"> JEE [ADVANCED]</a>
                      </h5>
                    </div>
                    <div id="collapse-2" class="collapse hide" role="tabpanel" aria-labelledby="headingOne">
                      <div class="card-block padding-30px text-justify">
                        <p>The best way to get familiar with the JEE Advanced Paper Pattern is to solve.</p>
                        <p>Previous years’ IIT JEE and JEE Advanced question papers. It helps one form an idea about the types of questions one should expect in the exam and number of questions in each subject to be solved in the specified JEE Advanced paper duration.</p>
                        <p>NOTE: The paper pattern of JEE[Advanced] is not fixed and is subject to change each year.</p>
                        <p>JEE ADVANCED EXAM PATTERN.</p>
                        <p>The JEE Advanced Paper Pattern states that the exam will have two papers: Paper 1 and Paper 2.</p>
                        <p>The question papers will only be available in two languages – English and Hindi. Candidates will have to choose the medium they prefer at the time of applying for the exam.</p>
                        <p>Each paper will have three sections and exam duration of three hours:</p>
                        <p>Section 1 will be Physics Section 2 will be Chemistry Section 3 will be Mathematics.</p>
                        <p><b>IMPORTANT: :</b></p>
                        <p>Last year, many students had not been able to solve Mathematics section completely due to time constraints. Hence, it is very important to practice time management for JEE exams. JEE Advanced 2018 questions will be designed to test the comprehension, reasoning and analytical ability of students. Questions will be objective-type and Multiple Choice Questions (MCQs). There is negative marking in the exam to discourage random guessing by students..</p>
                        <p>PAPER 1</p>
                        <p>Section 1 will have 10 MCQs. Each question will have four options with only one correct answer.</p>
                        <p>Section 2 will have 5 MCQs. Each question will have four options with one or more correct answer(s).</p>
                        <p>Section 3 will have 5 questions with answers in single digit integer ranging from 0 to 9.</p>
                        <p>Section 1 will have 8 MCQs. Each question will have four options with one or more correct answer(s).</p>
                        <p>Section 2 will have 8 MCQs. Each question will have four options with only one correct answer. This section will have four paragraphs with theory, practical aspects, data etc. 2 questions will be asked from each paragraph.</p>
                        <p>Section 3 will have Matching List type questions. Two lists will be given with matching options coded as a, b, c, and d. Students will have to choose options according to the given code.</p>
                        <p>PAPER 2</p>
                        <p>The Upper sheet of the Answer booklet will be the Optical Response Sheet (ORS), which is designed in a way that machines can read your answers. It will have two pages stuck together with no carbon in between.</p>
                        <p>Candidates will have to mark the appropriate bubbles for each question on the front page, which will automatically be recorded in the sheet below. Hence, students must be careful that they do not disturb the alignment between these two sheets or separate them at any point of the exam.</p>
                        <p>Do remember that you have to use only the black ball point pen for the exam. Also, read the instructions carefully as you cannot change the answers you have marked already. Apply adequate pressure on the answer sheet. The pressure should not be too much to pierce the bubbles or so light that the impressions on the second sheet are not visible properly. The invigilator will give you the copy of the sheet at the end of the exam which you can match with the JEE Advanced answer key later.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="tab-pane background-light-grey padding-30px" id="profile-1" role="tabpanel">
                <div class="card">
                  <div class="card-header" role="tab" id="headingOne">
                    <h5 class="mb-0">
                      <a data-toggle="collapse" data-parent="#accordion" href="#collapse-3" aria-expanded="true" aria-controls="collapseOne" class="d-block text-dark text-capitalize text-up-small font-weight-700">Syllabus of JEE Advanced</a>
                    </h5>
                  </div>
                  <div id="collapse-3" class="collapse hide" role="tabpanel" aria-labelledby="headingOne">
                    <div class="card-block padding-30px text-justify">
                      <p>PHYSICS</p>
                      <p>GENERAL</p>
                      <p>Units and dimensions, dimensional analysis; least count, significant figures; Methods of measurement and error analysis for physical quantities pertaining to the following experiments: Experiments based on using Vernier calipers and screw gauge (micrometer), Determination of g using simple pendulum, Young’s modulus by Searle’s method, Specific heat of a liquid using calorimeter, focal length of a concave mirror and a convex lens using u-v method, Speed of sound using resonance column, Verification of Ohm’s law using voltmeter and ammeter, and specific resistance of the material of a wire using meter bridge and post office box.</p>
                      <p>MECHANICS </p>
                      <p>Kinematics in one and two dimensions (Cartesian coordinates only), projectiles; Uniform circular motion; Relative velocity.
                        Newton’s laws of motion; Inertial and uniformly accelerated frames of reference; Static and dynamic friction; Kinetic and potential energy; Work and power; Conservation of linear momentum and mechanical energy. Systems of particles; Centre of mass and its motion; Impulse; Elastic and inelastic collisions. Law of gravitation; Gravitational potential and field; Acceleration due to gravity; Motion of planets and satellites in circular orbits; Escape velocity.
                        Rigid body, moment of inertia, parallel and perpendicular axes theorems, moment of inertia of uniform bodies with simple geometrical shapes; Angular momentum; Torque; Conservation of angular momentum; Dynamics of rigid bodies with fixed axis of rotation; Rolling without slipping of rings, cylinders and spheres; Equilibrium of rigid bodies; Collision of point masses with rigid bodies. Linear and angular simple harmonic motions. Hooke’s law, Young’s modulus. Pressure in a fluid; Pascal’s law; Buoyancy; Surface energy and surface tension, capillary rise; Viscosity (Poiseuille’s equation excluded), Stoke’s law; Terminal velocity, Streamline flow, equation of continuity, Bernoulli’s theorem and its applications. 
                        Wave motion (plane waves only), longitudinal and transverse waves, superposition of waves; Progressive and stationary waves; Vibration of strings and air columns; Resonance; Beats; Speed of sound in gases; Doppler effect (in sound).
                      </p>
                      <p>THERMAL PHYSICS </p>
                      <p>Thermal expansion of solids, liquids and gases; Calorimetry, latent heat; Heat conduction in one dimension; Elementary concepts of convection and radiation; Newton’s law of cooling; Ideal gas laws; Specific heats (Cv and Cp for monoatomic and diatomic gases); Isothermal and adiabatic processes, bulk modulus of gases; Equivalence of heat and work; First law of thermodynamics and its applications (only for ideal gases); Blackbody radiation: absorptive and emissive powers; Kirchhoff’s law; Wien’s displacement law, Stefan’s law. </p>
                      <p>ELECTRICITY AND MAGNETISM </p>
                      <p>Coulomb’s law; Electric field and potential; Electrical potential energy of a system of point charges and of electrical dipoles in a uniform electrostatic field; Electric field lines; Flux of electric field; Gauss’s law and its application in simple cases, such as, to find field due to infinitely long straight wire, uniformly charged infinite plane sheet and uniformly charged thin spherical shell.
                        Capacitance; Parallel plate capacitor with and without dielectrics; Capacitors in series and parallel; Energy stored in a capacitor. 
                        Electric current; Ohm’s law; Series and parallel arrangements of resistances and cells; Kirchhoff’s laws and simple applications; Heating effect of current.
                        Biot–Savart’s law and Ampere’s law; Magnetic field near a current-carrying straight wire, along the axis of a circular coil and inside a long straight solenoid; Force on a moving charge and on a current-carrying wire in a uniform magnetic field. 
                        Magnetic moment of a current loop; Effect of a uniform magnetic field on a current loop; Moving coil galvanometer, voltmeter, ammeter and their conversions.
                        Electromagnetic induction: Faraday’s law, Lenz’s law; Self and mutual inductance; RC, LR and LC circuits with d.c. and a.c. sources.
                      </p>
                      <p>OPTICS </p>
                      <p>Rectilinear propagation of light; Reflection and refraction at plane and spherical surfaces; Total internal reflection; Deviation and dispersion of light by a prism; Thin lenses; Combinations of mirrors and thin lenses; Magnification.
                        Wave nature of light: Huygen’s principle, interference limited to Young’s double-slit experiment.
                      </p>
                      <p>MODERN PHYSICS</p>
                      <p>Atomic nucleus; α, β and γ radiations; Law of radioactive decay; Decay constant; Half-life and mean life; Binding energy and its calculation; Fission and fusion processes; Energy calculation in these processes.
                        Photoelectric effect; Bohr’s theory of hydrogen-like atoms; Characteristic and continuous X-rays, Moseley’s law; de Broglie wavelength of matter waves.
                      </p>
                      <p>CHEMISTRY | PHYSICAL CHEMISTRY</p>
                      <p>GENERAL TOPICS Concept of atoms and molecules; Dalton’s atomic theory; Mole concept; Chemical formulae; Balanced chemical equations; Calculations (based on mole concept) involving common oxidation-reduction, neutralisation, and displacement reactions; Concentration in terms of mole fraction, molarity, molality and normality.</p>
                      <p>GASEOUS AND LIQUID STATES</p>
                      <p>Absolute scale of temperature, ideal gas equation; Deviation from ideality, van der Waals equation; Kinetic theory of gases, average, root mean square and most probable velocities and their relation with temperature; Law of partial pressures; Vapour pressure; Diffusion of gases.</p>
                      <p>ATOMIC STRUCTURE AND CHEMICAL BONDING</p>
                      <p>Bohr model, spectrum of hydrogen atom, quantum numbers; Wave-particle duality, de Broglie hypothesis; Uncertainty principle; Qualitative quantum mechanical picture of hydrogen atom, shapes of s, p and d orbitals; Electronic configurations of elements (up to atomic number 36); Aufbau principle; Pauli’s exclusion principle and Hund’s rule; Orbital overlap and covalent bond; Hybridisation involving s, p and d orbitals only; Orbital energy diagrams for homonuclear diatomic species; Hydrogen bond; Polarity in molecules, dipole moment (qualitative aspects only); VSEPR model and shapes of molecules (linear, angular, triangular, square planar, pyramidal, square pyramidal, trigonal bipyramidal, tetrahedral and octahedral). </p>
                      <p>ENERGETICS</p>
                      <p>First law of thermodynamics; Internal energy, work and heat, pressure-volume work; Enthalpy, Hess’s law; Heat of reaction, fusion and vapourization; Second law of thermodynamics; Entropy; Free energy; Criterion of spontaneity.</p>
                      <p>CHEMICAL EQUILIBRIUM</p>
                      <p>Law of mass action; Equilibrium constant, Le Chatelier’s principle (effect of concentration, temperature and pressure); Significance of ΔG and ΔG0 in chemical equilibrium; Solubility product, common ion effect, pH and buffer solutions; Acids and bases (Bronsted and Lewis concepts); Hydrolysis of salts.</p>
                      <p>ELECTROCHEMISTRY</p>
                      <p>Electrochemical cells and cell reactions; Standard electrode potentials; Nernst equation and its relation to ΔG; Electrochemical series, emf of galvanic cells; Faraday’s laws of electrolysis; Electrolytic conductance, specific, equivalent and molar conductivity, Kohlrausch’s law; Concentration cells.</p>
                      <p>CHEMICAL KINETICS</p>
                      <p>Rates of chemical reactions; Order of reactions; Rate constant; First order reactions; Temperature dependence of rate constant (Arrhenius equation).</p>
                      <p>SOLID STATE</p>
                      <p>Classification of solids, crystalline state, seven crystal systems (cell parameters a, b, c, α, β, γ), close packed structure of solids (cubic), packing in fcc, bcc and hcp lattices; Nearest neighbours, ionic radii, simple ionic compounds, point defects.</p>
                      <p>SOLUTIONS</p>
                      <p>Raoult’s law; Molecular weight determination from lowering of vapour pressure, elevation of boiling point and depression of freezing point.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php require_once('include/get-in-touch.php');?>
    <?php require_once('include/footer.php');?>
    <?php require_once('include/footer-js.php');?>
  </body>
</html>
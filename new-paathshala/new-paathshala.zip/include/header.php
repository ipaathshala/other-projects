  <header class="gradient-white box-shadow">
  <div class="background-main-color padding-tb-5px position-relative">
    <div class="container">
      <div class="row">
        <div class="col-xl-5  d-none d-xl-block">
          <div class="contact-info text-white">
            <span class="margin-right-10px">Call us: 9867998388</span>
            <span>Email: headoffice@paathshala.world</span>
          </div>
        </div>
        <div class="col-xl-7 col-lg-4  d-none d-lg-block">
          <ul class="user-area list-inline float-right margin-0px text-white">
            <li class="list-inline-item"><a href="#"> ENQUIRY | </a></li>
            <li class="list-inline-item"><a href="#"> ADMISSION |</a></li>
            <!--<li class="list-inline-item"><a href="professor"> PROFESSORS |</a></li>-->
            <li class="list-inline-item"><a href="#"> DLP / E - LEARNING |</a></li>
            <li class="list-inline-item"><a href="careers"> CAREERS |</a></li>
            <!--<li class="list-inline-item"><a href="#"> STORE |</a></li>
              <li class="list-inline-item"><a href="#"> ABHYAS |</a></li>-->
            <li class="list-inline-item"><a href="#"> RESOURCES |</a></li>
            <li class="list-inline-item"><a href="#"> LOGIN </a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <div class="header-output">
    <div class="container header-in">
      <div class="row">
        <div class="col-xl-2 col-lg-2">
          <a id="logo" href="index" class="d-inline-block margin-tb-10px"><img src="assets/img/logo/ps.png" alt=""></a>
          <a class="mobile-toggle padding-15px background-main-color" href="#"><i class="fas fa-bars"></i></a>
        </div>
        <div class="col-xl-8 col-lg-9 position-inherit">
          <div class="float-lg-right">
            <ul id="menu-main" class="float-lg-left nav-menu link-padding-tb-25px dropdown-dark">
              <li class="active"><a href="index">HOME</a></li>
              <li class=""><a href="about-us">ABOUT US</a></li>
              <li class=""><a href="why-paathshala">WHY PAATHSHALA</a></li>
              <li class="has-dropdown">
                <a class="dropdown" href="#">EXAMS  </a>
                <ul class="sub-menu">
                  <li class="has-dropdown"><a href="engineering-entrance-exam">JEE [MAIN], JEE [ADVANCED]</a></li>
                  <li class="has-dropdown"><a href="bitsat-cet">BITSAT, CET</a></li>
                  <li class="has-dropdown"><a href="#">NEET, AIIMS, JIPMER</a></li>
                  <li class="has-dropdown"><a href="#">OLYMPIADS</a></li>
                  <li class="has-dropdown"><a href="#">KVPY, IISER</a></li>
                  <li class="has-dropdown"><a href="#">FOUNDATION</a></li>
                </ul>
              </li>
              <li class=""><a href="result">RESULTS</a></li>
              <li class=""><a href="testimonial">TESTIMONIALS</a></li>
              <li class=""><a href="contact-us">CONTACT US</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</header>
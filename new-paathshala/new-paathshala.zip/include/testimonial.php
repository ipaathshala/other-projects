<section class="padding-tb-100px" style="background-image: url('assets/img/banner_17.jpg'); visibility: visible; animation-name: fadeInUp;">
  <div class="container">
    <div class="text-center margin-bottom-35px wow fadeInUp">
      <h1 class="font-weight-300 text-title-large font-3">Testimonial</h1>
      <span class="opacity-7">Lorem Ipsum Dolor Sit Amet, Consectetur Adipisicing Elitdunt</span>
    </div>
    <div class="testimonial-carousel owl-carousel owl-theme wow fadeInUp">
      <div class="row">
        <div class="col-lg-12">
          <div class="item margin-lr-15px">
            <div class="background-white opacity-hover-7 padding-30px">
              <div class="float-left width-100px margin-right-20px">
                <img src="assets/img/zoal_1.jpg" alt="">
              </div>
              <h4 class="margin-bottom-0px">Rabie Elkheir</h4>
              <small>Web Designer</small>
              <hr>
              <p class="text-grey-2">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!DOCTYPE html>
<html lang="en-US">
  <head>
    <title>Why Paathshala Education</title>
    <meta name="author" content="Nile-Theme">
    <meta name="robots" content="index follow">
    <meta name="googlebot" content="index follow">
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php require_once('include/header-css.php');?>
  </head>
  <body class="background-white">
    <!-- header -->
    <?php require_once('include/header.php');?>
    <!-- Page title --->
    <section class="background-grey-1 padding-tb-25px text-grey-4">
      <div class="container">
        <ol class="breadcrumb z-index-2 position-relative no-background padding-tb-10px padding-lr-0px  margin-0px float-md-right">
          <li><a href="index" class="text-grey-4">Home</a></li>
          <li><strong>You are here</strong></li>
          <li class="active"><strong>Why Paathshala</strong></li>
        </ol>
        <div class="clearfix"></div>
      </div>
    </section>
    <div class="margin-tb-50px">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-md-12">
            <h1 class="font-weight-300 text-title-large font-3 text-center">WHY PAATHSHALA</h1>
            <h1 class="margin-bottom-30px  text-large padding-tb-5px text-center">STANDARD FEATURES</h1>
            <div id="accordion" role="tablist" aria-multiselectable="true" class="margin-bottom-100px">
              <div class="card">
                <div class="card-header" role="tab" id="headingOne">
                  <h5 class="mb-0">
                    <a data-toggle="collapse" data-parent="#accordion" href="#collapse-1" aria-expanded="true" aria-controls="collapseOne" class="d-block text-dark text-capitalize text-up-small font-weight-700"> Dedicated,Well Qualified and Well Trained Professors</a>
                  </h5>
                </div>
                <div id="collapse-1" class="collapse show" role="tabpanel" aria-labelledby="headingOne">
                  <div class="card-block padding-30px text-justify">
                    The professors are well qualified, smart, jovial, charismatic individuals who undergo a rigorous teacher training and selection procedure instilling in them Paathshala values like dedication,approachability, approachability,clarity of knowledge and time management efficiency. They are well-known to simplify the topic and concepts for the students who develop interest and start performing better thenceforth. Our Professors derive great pride from their student's ranks and results and the believe in the philosophy that success in competitive exams is not only the student’s but the teachers as well to cherish.
                  </div>
                </div>
              </div>
              <div class="card">
                <div class="card-header" role="tab" id="headingOne">
                  <h5 class="mb-0">
                    <a data-toggle="collapse" data-parent="#accordion" href="#collapse-2" aria-expanded="true" aria-controls="collapseOne" class="d-block text-dark text-capitalize text-up-small font-weight-700"> 12 x 7,Air Conditioned Library Facility With Comfortable Seating</a>
                  </h5>
                </div>
                <div id="collapse-2" class="collapse hide" role="tabpanel" aria-labelledby="headingOne">
                  <div class="card-block padding-30px text-justify">
                    To ensure continued learning and concentration, we have designed our library with comfortable benches,study tables,12*7 air-conditioning facility because the environment in which a student is studying impacts the desire to study and concentration levels. The students can also consult the faculty available in the library premises for doubts clarification when the faculty are free from lectures. The library is open from 9 AM to 9 PM from Sunday to Saturday.
                  </div>
                </div>
              </div>
              <div class="card">
                <div class="card-header" role="tab" id="headingOne">
                  <h5 class="mb-0">
                    <a data-toggle="collapse" data-parent="#accordion" href="#collapse-3" aria-expanded="true" aria-controls="collapseOne" class="d-block text-dark text-capitalize text-up-small font-weight-700">Regular Assessments,Using Topic Wise Tests, Full, Syllabus Test &amp; Part Syllabus Test</a>
                  </h5>
                </div>
                <div id="collapse-3" class="collapse hide" role="tabpanel" aria-labelledby="headingOne">
                  <div class="card-block padding-30px text-justify">
                    The students will be regularly assessed through tests the marks of which would be communicated to the parents from time to time. Once the syllabus is completed, the students will be made to give full syllabus end-of-the course test series which would be of the same pattern as the competitive exams they are preparing for. Intermittently we also provide students with part syllabus tests. Because it is only practice that makes a student perfect.
                  </div>
                </div>
              </div>
              <div class="card">
                <div class="card-header" role="tab" id="headingOne">
                  <h5 class="mb-0">
                    <a data-toggle="collapse" data-parent="#accordion" href="#collapse-4" aria-expanded="true" aria-controls="collapseOne" class="d-block text-dark text-capitalize text-up-small font-weight-700"> Special Preparation For Board Exams</a>
                  </h5>
                </div>
                <div id="collapse-4" class="collapse hide" role="tabpanel" aria-labelledby="headingOne">
                  <div class="card-block padding-30px text-justify">
                    Paathshala conducts Special Preparation for Board Exams of the students towards the second half of the twelfth standard.This special coaching for the board examinations which includes making the students practice the board papers of previous years, evaluation and correction of the board papers, providing the appropriate feedback and suggestions, helps the students feel well prepared and confident. Expert faculties for board exams give tips as to how to write the board papers,how to make them look more presentable with legible handwriting, labelled diagrams and point wise answers in order to score well. This has helped numerous students of Paathshala Education to excel in board exams.
                  </div>
                </div>
              </div>
            </div>
            <h1 class="margin-bottom-30px  text-large padding-tb-5px text-center">UNIQUE FEATURES</h1>
            <div id="accordion-3" role="tablist" aria-multiselectable="true" class="margin-bottom-50px">
              <!--<div class="card">
                <div class="card-header" role="tab" id="headingOne">
                  <h5 class="mb-0">
                    <a data-toggle="collapse" data-parent="#accordion-3" href="#collapse-3-1" aria-expanded="true" aria-controls="collapseOne" class="d-block text-dark text-capitalize text-up-small font-weight-700">Technology Enhanced Learning and Teaching </a>
                  </h5>
                </div>
                <div id="collapse-3-1" class="collapse show" role="tabpanel" aria-labelledby="headingOne">
                  <div class="card-block padding-30px text-justify">
                    At Paathshala Education, We use ultramodern devices like a digital writing pad and our blackboard is most often a digital TV screen wherein the teacher can incorporate the use of interesting Educational Videos, Animations, Graphics and can show the students complex and to scale images instantly. This increases the interest and enthusiasm of the students towards studies and helps them understand better,In this technologically enhanced method of teaching,, assignments and in-class problems can be solved without the need of having to dictate or write down the question statement or drawing a diagram or writing too much data making the process of learning much faster and much more fun. The use of pen colors, drag and drop digital images, pen thickness variation and readymade formulae makes the teacher more productive and efficient in knowledge delivery and the student hence grasps the concepts with a higher degree of clarity.Not to mention the fact that our professors are very happy in lecturing like this, because they don’t need to stand for long hours and they avoid their legs and backs from getting fatigued while teaching. They can comfortably sit and focus on knowledge delivery instead of dealing with the inevitable back and leg pain that may arise due to long hours of standing and teaching.
                  </div>
                </div>
              </div>-->
              <div class="card">
                <div class="card-header" role="tab" id="headingOne">
                  <h5 class="mb-0">
                    <a data-toggle="collapse" data-parent="#accordion-3" href="#collapse-3-2" aria-expanded="true" aria-controls="collapseOne" class="d-block text-dark text-capitalize text-up-small font-weight-700">Teaching Using Models and Small Experiment In Class</a>
                  </h5>
                </div>
                <div id="collapse-3-2" class="collapse hide" role="tabpanel" aria-labelledby="headingOne">
                  <div class="card-block padding-30px text-justify">
                    In Paathshala classrooms, the use of teaching models and demonstrating small experiments in class, especially across a table and while learning topics like solid state chemistry and reaction mechanisms in organic chemistry, optical isomerism etc makes the student understand the concepts involved much better and faster and this leads the student having more knowledge and deeper understanding about such complicated topics involving spatial reasoning.
                  </div>
                </div>
              </div>
              
              
			  
			  
              <div class="card">
                <div class="card-header" role="tab" id="headingOne">
                  <h5 class="mb-0">
                    <a data-toggle="collapse" data-parent="#accordion-3" href="#collapse-3-5" aria-expanded="true" aria-controls="collapseOne" class="d-block text-dark text-capitalize text-up-small font-weight-700">Persistent Student Welfare Activities, Guidance, Motivation and Support</a>
                  </h5>
                </div>
                <div id="collapse-3-5" class="collapse hide" role="tabpanel" aria-labelledby="headingOne">
                  <div class="card-block padding-30px text-justify">
                    Student Welfare Activities, conducted by Paathshala Education act as a Continuous Motivation and Support system for students.There is a dedicated team of professionals called the Student Welfare Team, which is driven to provide constant support, guidance and counselling to the students on a regular basis. The students are supposed to report to the Student Welfare Team about what they have studied on a given day as a part of self study as well as classwork, and if they have any impending doubts. The progress of the student will be communicated to the parents on a weekly basis as a weekly study report with appropriate feedback and improvement suggestions. A short surprize viva may also conducted on the topics which have been covered by the student as a part of self study. This helps the student stay on the foot and re-enforces the concept of regular guided studies.
                  </div>
                </div>
              </div>
              <div class="card">
                <div class="card-header" role="tab" id="headingOne">
                  <h5 class="mb-0">
                    <a data-toggle="collapse" data-parent="#accordion-3" href="#collapse-3-6" aria-expanded="true" aria-controls="collapseOne" class="d-block text-dark text-capitalize text-up-small font-weight-700">Post Exam Counselling and Career Guidance</a>
                  </h5>
                </div>
                <div id="collapse-3-6" class="collapse hide" role="tabpanel" aria-labelledby="headingOne">
                  <div class="card-block padding-30px text-justify">
                    Post Exam Counselling and feedback is provided to students after they are done with their entrance exams and the results come out. Many a student is in a dilemma as to what institute or branch to choose amongst the several available to them. We explain to them in detail about all branches and try to establish medium term and long term career goals. Our counselors comprise of our faculty and well established industry professionals Thus they are more well informed about what exactly to choose and how to proceed in life.
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php require_once('include/footer.php');?>
    <?php require_once('include/footer-js.php');?>
  </body>
</html>
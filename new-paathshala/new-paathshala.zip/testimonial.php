  <!DOCTYPE html>
<html lang="en-US">
  <head>
    <title>Testimonial</title>
    <meta name="author" content="">
    <meta name="robots" content="">
    <meta name="googlebot" content="">
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php require_once('include/header-css.php');?>
  </head>
  <body class="background-white">
    <?php require_once('include/header.php'); ?>

    <div id="page-title" class="text-grey background-overlay background-img-dark padding-tb-300px" style="background-image: url('assets/img/testimonial.jpg');">
    <div class="text-center">
      <div class="container padding-tb-185px z-index-2 position-relative">
        
      </div>
      
    </div>

  </div>

    <div class="container padding-tb-100px">
      <div class="row">
        <div class="col-lg-12">
          <div class="blog-entry background-white border-1 border-grey-1 margin-bottom-35px">
            <div class="row no-gutters">
              <div class="img-in col-lg-3"><a href="#"><img src="demo-img/service-1.jpg" alt=""></a></div>
              <div class="col-lg-9">
                <div class="padding-25px">
                  <div class="d-block text-up-small text-grey-2 margin-bottom-10px text-justify">
                    <i class="fa fa-quote-left margin-right-10px"></i> My experience at Paathshala was amazing. The professors at Paathshala are very very good. They have provided personalized attention to us and helped us whenever required. Many doubts about careers and career opportunities were also clarified by the Academics Team. The counselors of the Academics Team have given us motivation counseling from time to time and the counseling really helped me a lot <i class="fa fa-quote-right margin-left-10px"></i>
                  </div>
                  <div class="meta">
                    <p><stong class="margin-right-20px">By : Tanmay Pawaskar</stong></p>
                  </div>
                </div>
              </div>
            </div>
            <div class="clearfix"></div>
          </div>
        </div>
        <div class="col-lg-12">
          <div class="blog-entry background-white border-1 border-grey-1 margin-bottom-35px">
            <div class="row no-gutters">
              <div class="img-in col-lg-3"><a href="#"><img src="demo-img/service-1.jpg" alt=""></a></div>
              <div class="col-lg-9">
                <div class="padding-25px">
                  <div class="d-block text-up-small text-grey-2 margin-bottom-10px">
                    <i class="fa fa-quote-left margin-right-10px"></i> Mauris fermentum porta sem, non hendrerit enim bibendum consectetur. Fusce diam est, porttitor vehicula gravida at <i class="fa fa-quote-right margin-left-10px"></i>
                  </div>
                  <div class="meta">
                    <span class="margin-right-20px">By : <a href="#" class="text-main-color">Rabie Elkheir</a></span>
                  </div>
                </div>
              </div>
            </div>
            <div class="clearfix"></div>
          </div>
        </div>
        <div class="col-lg-12">
          <div class="blog-entry background-white border-1 border-grey-1 margin-bottom-35px">
            <div class="row no-gutters">
              <div class="img-in col-lg-3"><a href="#"><img src="demo-img/service-1.jpg" alt=""></a></div>
              <div class="col-lg-9">
                <div class="padding-25px">
                  <div class="d-block text-up-small text-grey-2 margin-bottom-10px">
                    <i class="fa fa-quote-left margin-right-10px"></i> Mauris fermentum porta sem, non hendrerit enim bibendum consectetur. Fusce diam est, porttitor vehicula gravida at <i class="fa fa-quote-right margin-left-10px"></i>
                  </div>
                  <div class="meta">
                    <span class="margin-right-20px">By : <a href="#" class="text-main-color">Rabie Elkheir</a></span>
                  </div>
                </div>
              </div>
            </div>
            <div class="clearfix"></div>
          </div>
        </div>
      </div>
    </div>

    </div>
    <?php require_once('include/footer.php');?>
    <?php require_once('include/footer-js.php');?>
  </body>
</html>
<!DOCTYPE html>
<html lang="en-US">
  <head>
    <title>Contact Us</title>
    <meta name="author" content="">
    <meta name="robots" content="">
    <meta name="googlebot" content="">
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php require_once('include/header-css.php');?>
  </head>
  <body class="background-white">
    <!-- header -->
    <?php require_once('include/header.php');?>
    <!-- Page title --->
    <section class="background-grey-1 padding-tb-25px text-grey-4">
      <div class="container">
        <ol class="breadcrumb z-index-2 position-relative no-background padding-tb-10px padding-lr-0px  margin-0px float-md-right">
          <li><a href="index" class="text-grey-4">Home</a></li>
          <li><strong>You are here</strong></li>
          <li class="active"><strong>Contact Us</strong></li>
        </ol>
        <div class="clearfix"></div>
      </div>
    </section>
    <!-- Page title --->
    <!-- Page Output -->
    <section class="padding-tb-30px">
      <div class="container">
        <div class="row">
          <div class="col-lg-4 col-md-6">
            <b>Find us here</b>
            <h6 class="margin-top-20px">Head Office :</h6>
            <span class="d-block">201, Dighe House, Opp Karnavat Classes, Lohar Ali Lane, Behind Jagdish Book Depot, Near Thane Railway Station, Thane West - 400601, Maharashtra, India</span>
            <h6 class="margin-top-20px">Branch Office :</h6>
            <span class="d-block">203, Paradise Tower, Near Railway Station (Near McDonald’s), Thane West - 400602, Maharashtra, India</span>
          </div>
          <div class="col-lg-3 col-md-6">
            <b>Call us</b>
            <h6 class="margin-top-20px">Call us for :</h6>
            <span class="d-block"> Enquiries : +91 9867998388</span>
            <span class="d-block"> Admin Office : (022) 49708979</span>
            <span class="d-block"> Student Welfare : +91 9987457772</span>
          </div>
          <div class="col-lg-5 col-md-6">
            <b>Write us</b>
            <h6 class="margin-top-20px">Write email to us on :</h6>
            <span class="d-block"> Academics : academics@paathshala</span>
            <span class="d-block"> General : headoffice@paathshala.world</span>
            <span class="d-block"> Enquiries : enquiries@paathshala.world</span>
            <span class="d-block"> Student Welfare : academicexcellence@paathshala.world</span>
          </div>
        </div>
      </div>
    </section>
    <section class="padding-tb-30px">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 col-md-6">
            <h2 class="text-extra-large text-black margin-tb-10px">Contact Form</h2>
			<!--<div class="alert alert-success">
				<strong>Success!</strong> Indicates a successful or positive action.
			</div>
			<div class="alert alert-danger">
				<strong>Success!</strong> Indicates a successful or positive action.
			</div>-->
            <form action="#">
              <div class="form-row">
                <div class="form-group col-md-4">
                  <label >Name</label>
                  <input type="text" class="form-control" id="inputName4">
                </div>
                <div class="form-group col-md-4">
                  <label >Email</label>
                  <input type="text" class="form-control" id="inputEmail4">
                </div>
                <div class="form-group col-md-4">
                  <label >Mobile Number</label>
                  <input type="text" class="form-control" id="inputEmail4">
                </div>
              </div>
              <div class="form-group">
                <label>Message</label>
                <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
              </div>
              <button class="btn-sm btn-lg btn-success btn" type="button" name="submit">SEND MESSAGE</button>
            </form>
          </div>
        </div>
      </div>
    </section>
    <!-- // Page Output -->
    <!-- Map -->
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3768.1851599662273!2d72.96851511538517!3d19.18711345345528!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7b9201694f829%3A0x144d25cf68c780c2!2sPAATHSHALA+EDUCATION!5e0!3m2!1sen!2sin!4v1540548915222"  frameborder="0" style="border:0; width:100%; height:600px;" allowfullscreen></iframe>
    <?php require_once('include/footer.php');?>
    <?php require_once('include/footer-js.php');?>
  </body>
</html>